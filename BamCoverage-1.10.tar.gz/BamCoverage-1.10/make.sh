#!/bin/sh
#$ -S /bin/sh
echo Start Time : 
date
echo g++ -g  -O2	src/BamCoverage.cpp -lhts	-lgzstream	-lz	-L	src/gzstream/	-L	src/zlib/	-o	bin/BamCoverage 
# you can add the [ -I /path/.../samtools-1.6/htslib-1.6   -L /path/.../samtools-1.6/htslib-1.6 ] here if can find the htslib
g++ -g  -O2	src/BamCoverage.cpp -lhts	-lgzstream	-lz	-L	src/gzstream/	-L	src/zlib/	-o	bin/BamCoverage -I./src/hts_include  -L./src/hts_lib
# you can add the [ -I /path/.../samtools-1.6/htslib-1.6   -L /path/.../samtools-1.6/htslib-1.6 ] here if can find the htslib
echo End Time :
date
